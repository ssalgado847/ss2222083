/* 
 * File:   main.cpp
 * Author: Sandra Salgado
 * Purpose: Personal Information
 * Created on January 10, 2016, 10:43 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
// name, address_city_state_zip, number, college major
    cout << "Sandra Salgado" << "1380 Detroit st. Norco,CA 92860" <<
            "951-531-7377" << "Computer Science" << endl; 
    return 0;
}

