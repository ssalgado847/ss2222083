
/* 
 * File:   main.cpp
 * Author: Sandra Salgado
 * Purpose: Sum of Two Numbers
 * Created on January 10, 2016, 11:54 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    unsigned short num1 = 62,
            num2 = 99,
            total;
    
//calculate total
    total = num1 + num2;
    cout << "Total: " << total << endl;
    return 0;
}

